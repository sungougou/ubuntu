#!/usr/bin/env python
# encoding:utf-8
""" 
        说明：Stanly法轨迹跟踪（基于几何计算，不涉及模型进行优化）Stanly法追踪前轮最近点，进行横向距离消除，并且
        纵向距离和速度有关。
        订阅的话题：
        1、规划好的路线/splinepoints
        2、小车的位置（Stanly法前轮中心）/smart/front_pose
        3、小车的速度/smart/velocity
        主函数步骤：
        1、创建发布者用于发布小车控制命令Twist
        2、订阅规划路径，将路径格式转化为坐标点
        3、订阅小车速度
        4、订阅小车前轮位置，核心函数，计算需要转动的角度发布到/smart/cmd_vel

 """
import rospy
from nav_msgs.msg import Path
from geometry_msgs.msg import TwistStamped,PoseStamped,Twist
import tf_conversions
from math import pow, sqrt, atan2, sin,cos


# 0、初始化全局变量
pointnum = 0
path_x = []
path_y = []

velocity = 0

k = 0.25
ks = 0.1
theta_point = 0
theta_distance = 0
pi = 3.1415926

# 回调函数必须接受参数，不然会报错
def pointcallback(path):
        global pointnum,path_x,path_y###
        pointnum = len(path.poses)###
        path_x = [pose.pose.position.x for pose in path.poses]###
        path_y = [pose.pose.position.y for pose in path.poses]
        rospy.loginfo("路径装填完毕")

def velocitycallback(vel):
        global velocity
        velocity = vel.twist.linear.x###千万注意，速度的消息用twist类型数据装填

def posecallback(pose):
        #将小车坐标信息进行赋值，方便处理
        currentpositionx = pose.pose.position.x
        currentpositiony = pose.pose.position.y
        currentpositionz = 0
        #欧拉角三元数，里面装着车的角度
        oula = tf_conversions.transformations.euler_from_quaternion([pose.pose.orientation.x,
                                                                    pose.pose.orientation.y,
                                                                    pose.pose.orientation.z,
                                                                    pose.pose.orientation.w])
        #rospy.loginfo("小车点装填完毕")
        #首先寻找前轮最近点：当前点和索引点之间的距离
        bestpoints = [sqrt(pow(currentpositionx-x,2)+pow(currentpositiony-y,2)) for x,y in zip(path_x,path_y)]
        index = bestpoints.index(min(bestpoints))###这句代码好好理解！！！
        
        distance = sqrt(pow(currentpositionx-path_x[index],2)+pow(currentpositiony-path_y[index],2))#这个距离就是要消除的距离
        
        # 1、计算前馈角度差，用来计算跟踪点的切线值
        if index < len(path_x) - 1:
                dx = path_x[index+1] - path_x[index]
                dy = path_y[index+1] - path_y[index]
        else:
                dx = path_x[index] - path_x[index-1]
                dy = path_y[index] - path_y[index-1]
        angle_point = atan2(dy,dx)
        angle_car = oula[2]#车辆的当前角度
        frontback = (angle_point - angle_car)*1.5
        
        # 2、计算反馈角度差，判断车辆在车道左边还是右边
        array_point = [dx,dy]
        array_car_90 = [cos(oula[2]-pi/2),sin(oula[2]-pi/2)]
        temp = array_point[0]*array_car_90[0] + array_point[1]*array_car_90[1]
        if temp > 0:
                angle = 1
        else:
                angle = -1 

        # angle大于0，小车在道路右边，转动的角度大于0
        feedback = atan2(k*distance,velocity) * angle
        
        # 3、发布转向消息
        twist = Twist()
        #如果追踪到最后一个点就停下来
        if index == pointnum-1:
                twist.linear.x = 0
        else:
                twist.linear.x = 5#匀速行使
        twist.angular.z = feedback + frontback
        pub.publish(twist)

if __name__ == "__main__":
        # 0、初始化
        rospy.init_node("stanly_pursuit")
        # 1、创建发布者用于发布小车控制命令Twist
        pub = rospy.Publisher("/smart/cmd_vel",Twist,queue_size=10)
        # 2、订阅规划路径，将路径格式转化为坐标点
        rospy.Subscriber("/splinepoints",Path,pointcallback,queue_size=20)
        # 3、订阅小车速度
        rospy.Subscriber("/smart/velocity",TwistStamped,velocitycallback,queue_size=20)
        # 4、订阅小车后轮位置，核心函数，计算需要转动的角度/smart/cmd_vel
        rospy.Subscriber("/smart/front_pose",PoseStamped,posecallback,queue_size=20)
        
        rospy.spin()