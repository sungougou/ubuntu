current_pose = None  # 用于存储小车的最新位置和姿态

# 定义定时器，使得小车位置更新和PID控制器分离
# def pid_control_callback(event):
#     global current_pose, current_time
#     # 如果当前的小车位置没有被更新过，则直接返回
#     if current_pose is None:
#         return
    
#     # 计算dt
#     last_time = current_time
#     current_time = event.current_real.to_sec()
#     dt = current_time - last_time

#     # 这里执行你的PID计算逻辑，使用current_pose作为小车的当前位置
    
#     # ...
#     # 记得到处更新e_last以便下一次回调使用
#     e_last = e_now
    
#     # 使用dt作为你的PID时间间隔
    # current_time = rospy.get_time()  # 获取当前时间
    # control_timer = rospy.Timer(rospy.Duration(0.1),pid_control_callback)  # 定时器来调度PID控制