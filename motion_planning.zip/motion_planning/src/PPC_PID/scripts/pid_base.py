#! /usr/bin/env python
# encoding:utf-8
# PID进行轨迹跟踪仿真实验，成功追踪，需要改进。
import rospy
from math import pow, sqrt, atan2, sin,atan2,cos
from geometry_msgs.msg import Twist, PoseStamped,TwistStamped
from nav_msgs.msg import Path
from tf.transformations import euler_from_quaternion

""" 
        说明目的：先尝试PID的首次仿真
        算法：选取一定距离的育苗点，计算法向量上的横向误差作为状态变量
        订阅的话题：
        1、规划好的路线/splinepoints
        2、小车的位置（纯追踪法后轮中心） /smart/rear_pose
        3、小车的速度，用于计算育苗距离！/smart/velocity
        主函数：
        1、订阅路径，初始化
        2、订阅小车速度，用不到，后续进行优化
        3、订阅小车为位置，核心计算出横向误差，发布PID控制

 """

PREVIEW_DIS = 0.1  #基本预瞄距离
Ld = 1.868  #轴距，用于纯追踪法的核心公式

k = 0.1
carVelocity = 0  #初始化车速和育苗距离
preview_dis = 0

pointNum = 0  #路径点的总数，用于进行路经点索引
r_x_ = []  #数组的定义：空数组是可以的！路径的横纵坐标，我们进行任何的几何计算肯定需要点坐标！！！
r_y_ = []
Kp = 20
Ki = 20
Kd = 20
e_now = 0
e_last = 0
integral = 0
derivate = 0
PI = 3.1415926
index_flag = 0

def poseCallback(currentWaypoint):
    #函数中我们需要声明全局变量才有资格在函数中使用，不然默认是局部变量
    global preview_dis, pointNum, r_x_, r_y_,current_time,last_time,e_now,e_last,Kp,Ki,Kd,integral,derivate
    global index_flag
    currentPositionX = currentWaypoint.pose.position.x
    currentPositionY = currentWaypoint.pose.position.y
    currentPositionZ = 0.0
    
    quaternion = (
        currentWaypoint.pose.orientation.x,
        currentWaypoint.pose.orientation.y,
        currentWaypoint.pose.orientation.z,
        currentWaypoint.pose.orientation.w)
    euler = euler_from_quaternion(quaternion)
    
    # 方案二:先从当前位置附近找到一个最近点，然后从最近点往后寻找临近预眇距离的坐标点
    bestPoints_ = [sqrt(pow(x - currentPositionX, 2) + pow(y - currentPositionY, 2)) for x, y in zip(r_x_, r_y_)]
    index = bestPoints_.index(min(bestPoints_))
    if (index - index_flag)!=0:
        integral = 0#对i清零，在每次更新index时清零
        index_flag = index
    for i in range(index, pointNum):
        dis = sqrt(pow(r_y_[index] - r_y_[i], 2) + pow(r_x_[index] - r_x_[i], 2));
        # 目标点：选取离最近点育苗距离的点作为育苗点！
        if dis >= preview_dis:
            index = i
            break

    # 计算小车控制指令！
    dl = sqrt(pow(r_y_[index] - currentPositionY, 2) + pow(r_x_[index] - currentPositionX, 2))
    if dl > 0.1:
        current_time = rospy.Time.now()
        dt = (current_time - last_time).to_sec()#计算模拟时间间隔，时间time不是数据类型，需要转换
        
        if dt>0:#核心部分：进行PID控制
            vel_msg = Twist()
            vel_msg.linear.x = 3
            # # 方法一：横向距离作为误差
            # dis = np.array([r_x_[index]-currentPositionX, r_y_[index]-currentPositionY])
            # theta = np.arctan2(r_y_[index+1]-r_y_[index], r_x_[index+1]-r_x_[index])
            # # 计算切向量
            # tor = np.array([np.cos(theta), np.sin(theta)])
            # # 计算法向量
            # nor = np.array([-np.sin(theta), np.cos(theta)])
            # # 计算横向误差，用于pid控制
            # e_now = np.dot(nor, dis)
            # 方法二：角度作为误差输入
            theta = atan2(r_y_[index] - currentPositionY, r_x_[index] - currentPositionX) - euler[2]
            e_now = theta
            e = e_now - e_last
            integral += dt*e_now
            derivate = (e_now - e_last)/dt
            vel_msg.angular.z = Kp*e_now + Ki*integral + Kd*derivate
            if vel_msg.angular.z > PI/2:
                vel_msg.angular.z = PI/2
            elif vel_msg.angular.z < PI/2:
                vel_msg.angular.z = -PI/2
            pub_vel.publish(vel_msg)
        elif dt==0:#处理dt异常的时刻
            vel_msg = Twist()
            vel_msg.linear.x = 0
            vel_msg.angular.z = 0
            pub_vel.publish(vel_msg)
        # 最后更新last_time
        last_time = current_time
        e_last = e_now

    else:#处理终点时刻
        vel_msg = Twist()
        vel_msg.linear.x = 0
        vel_msg.angular.z = 0
        pub_vel.publish(vel_msg)

def velocityCall(carWaypoint):
    global carVelocity, preview_dis
    carVelocity = carWaypoint.twist.linear.x
    preview_dis = k * carVelocity + PREVIEW_DIS


def pointCallback(msg):
    global pointNum, r_x_, r_y_
    pointNum = len(msg.poses)
    r_x_ = [pose.pose.position.x for pose in msg.poses]
    r_y_ = [pose.pose.position.y for pose in msg.poses]

if __name__ == "__main__":
    rospy.init_node("pure_pursuit")
    #时间要在初始化节点后使用
    current_time = rospy.Time.now()
    last_time = rospy.Time.now()
    pub_vel = rospy.Publisher("/smart/cmd_vel", Twist, queue_size=20)

    path = Path()
    path.header.frame_id = "world"
    path.header.stamp = rospy.Time.now()

    rospy.Subscriber("/splinepoints", Path, pointCallback)
    rospy.Subscriber("/smart/velocity", TwistStamped, velocityCall)
    rospy.Subscriber("/smart/rear_pose", PoseStamped, poseCallback)

    rospy.spin()