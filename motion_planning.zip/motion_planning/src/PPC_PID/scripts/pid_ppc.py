#! /usr/bin/env python
# encoding:utf-8
# PID-PPC
import rospy
from math import pow, sqrt, atan2, sin,atan2,cos
from geometry_msgs.msg import Twist, PoseStamped,TwistStamped,Quaternion
from nav_msgs.msg import Path
from tf.transformations import euler_from_quaternion,quaternion_from_euler
import numpy as np
""" 
        说明目的：对PID的预设性能控制
        算法：选取一定距离的育苗点，计算法向量上的横向误差作为状态变量
        订阅的话题：
        1、规划好的路线/splinepoints
        2、小车的位置（纯追踪法后轮中心） /smart/rear_pose
        3、小车的速度，用于计算育苗距离！/smart/velocity
        主函数：
        1、订阅路径，初始化
        2、订阅小车速度，用不到，后续进行优化
        3、订阅小车为位置，核心计算出横向误差，发布PID控制

 """

PREVIEW_DIS = 1  #基本预瞄距离
Ld = 1.868  #轴距，用于纯追踪法的核心公式

k = 0.1
carVelocity = 0  #初始化车速和育苗距离
preview_dis = 0

pointNum = 0  #路径点的总数，用于进行路经点索引
r_x_ = []  #数组的定义：空数组是可以的！路径的横纵坐标，我们进行任何的几何计算肯定需要点坐标！！！
r_y_ = []
Kp = 20
Ki = 40
Kd = 20
e_now = 0
e_last = 0
integral = 0
derivate = 0
PI = 3.1415926
euler = []
currentPositionX = 0
currentPositionY = 0
currentPositionZ = 0

epsilon_last = 0
epsilon_now = 0
index_flag = 0
theta = 0

# 位置更新回调函数，此处仅仅用于位置更新
def poseCallback(currentWaypoint):
    #函数中我们需要声明全局变量才有资格在函数中使用，不然默认是局部变量
    global currentPositionX,currentPositionY,currentPositionZ,euler
    currentPositionX = currentWaypoint.pose.position.x
    currentPositionY = currentWaypoint.pose.position.y
    currentPositionZ = 0.0
    
    quaternion = (
        currentWaypoint.pose.orientation.x,
        currentWaypoint.pose.orientation.y,
        currentWaypoint.pose.orientation.z,
        currentWaypoint.pose.orientation.w)
    euler = euler_from_quaternion(quaternion)

def velocityCall(carWaypoint):
    global carVelocity, preview_dis
    carVelocity = carWaypoint.twist.linear.x
    preview_dis = k * carVelocity + PREVIEW_DIS


def pointCallback(msg):
    global pointNum, r_x_, r_y_
    pointNum = len(msg.poses)
    r_x_ = [pose.pose.position.x for pose in msg.poses]
    r_y_ = [pose.pose.position.y for pose in msg.poses]

# 定时器回调函数，用于PID控制
def pid_control_callback(event):
    global currentPositionX,currentPositionY,currentPositionZ
    global preview_dis, pointNum, r_x_, r_y_,current_time,last_time,e_now,e_last,Kp,Ki,Kd,integral,derivate,start_time
    global epsilon_last,epsilon_now,index_flag,path,theta    
        # 方案二:先从当前位置附近找到一个最近点，然后从最近点往后寻找临近预眇距离的坐标点
    bestPoints_ = [sqrt(pow(x - currentPositionX, 2) + pow(y - currentPositionY, 2)) for x, y in zip(r_x_, r_y_)]
    index = bestPoints_.index(min(bestPoints_))

    for i in range(index, pointNum):
        dis = sqrt(pow(r_y_[index] - r_y_[i], 2) + pow(r_x_[index] - r_x_[i], 2));
        # 目标点：选取离最近点育苗距离的点作为育苗点！
        if dis >= preview_dis:
            index = i
            break

    # 计算小车控制指令！
    dl = sqrt(pow(r_y_[index] - currentPositionY, 2) + pow(r_x_[index] - currentPositionX, 2))
    if dl > 0.3:
        # 计算dt
        last_time = current_time
        current_time = rospy.Time.now().to_sec()
        dt = current_time - last_time
        
        if dt>0:#核心部分：进行PID控制
            vel_msg = Twist()
            vel_msg.linear.x = 3
            # # 方法一：横向距离作为误差
            # dis = np.array([r_x_[index]-currentPositionX, r_y_[index]-currentPositionY])
            # theta = np.arctan2(r_y_[index+1]-r_y_[index], r_x_[index+1]-r_x_[index])
            # # 计算切向量
            # tor = np.array([np.cos(theta), np.sin(theta)])
            # # 计算法向量
            # nor = np.array([-np.sin(theta), np.cos(theta)])
            # # 计算横向误差，用于pid控制
            # e_now = np.dot(nor, dis)
            # 方法二：角度作为误差输入
            theta = atan2(r_y_[index] - currentPositionY, r_x_[index] - currentPositionX) - euler[2]
            e_now = theta
            
            #新增预设性能控制，对e转换成epsilon
            # 如果育苗点更新，重置时间t和误差e
            if (index - index_flag)!=0:
                integral = 0#对i清零，在每次更新index时清零
                start_time = rospy.Time.now().to_sec()# 设定预设性能函数的起始时间
                epsilon_last = 0######有待争议
                index_flag = index
            t = current_time - start_time
            pt = p(t)
            epsilon_now = error_trans(e_now,pt)
            integral += dt*epsilon_now
            derivate = (epsilon_now - epsilon_last)/dt
            vel_msg.angular.z = Kp*epsilon_now + Ki*integral + Kd*derivate
            #限制输出最大值
            if vel_msg.angular.z > PI/2:
                vel_msg.angular.z = PI/2
            elif vel_msg.angular.z < PI/2:
                vel_msg.angular.z = -PI/2
            pub_vel.publish(vel_msg)
        elif dt==0:#处理dt异常的时刻
            vel_msg = Twist()
            vel_msg.linear.x = 0
            vel_msg.angular.z = 0
            pub_vel.publish(vel_msg)
        # 最后更新last_time
        last_time = current_time
        epsilon_last = epsilon_now

    else:#处理终点时刻
        vel_msg = Twist()
        vel_msg.linear.x = 0
        vel_msg.angular.z = 0
        pub_vel.publish(vel_msg)
    publishpath(currentPositionX,currentPositionY,theta)

# 定义预设性能函数 p(t)。这个函数描述了性能目标随时间变化的边界。
def p(t):
    P0 = 1  # Change based on your scenario : PPC starting point
    Pi = 0.5  # Change based on your scenario : End of the PPC bounds
    t0 = 1  # Change based on your scenario : Time to reach to the Pi
    L = 1     # Change based on your scenario : PPC convergence rate

    # IMPORTANT NOTICE: If you intend to publish or use this formulation, citation is required.
    # Please refer to the original published work by Mohd Iskandar Putra:
    # https://www.sciencedirect.com/science/article/pii/S2667241323000149
    return np.real(((P0 - Pi) * np.exp((-5 / (t0**2)) * (t * (np.tanh(L * (t - t0)) + 1))**2)) + Pi)

# 转换函数，将误差e转化为epsilon！
def error_trans(e, pt):
    if abs(e) >= pt:
        return 0
    #转换函数中有1-e/pt部分，e代表误差，pt代表性能函数值，当误差很接近性能函数值时，分母极小，导致转化后的误差极其不稳定
    #为避免不稳定情况，在性能边界换一种变换方式
    eps = 1e-6
    if abs(e / pt) >= 1 - eps:
        return np.sign(e) * 0.5 * np.log(eps)

    return np.real(0.5 * np.log(((e / pt) + 1) / (1 - (e / pt))))

# 定义发布路径的函数
def publishpath(currentPositionX,currentPositionY,theta):
    this_pose_stamped = PoseStamped()
    this_pose_stamped.pose.position.x = currentPositionX
    this_pose_stamped.pose.position.y = currentPositionY
    quaternion = quaternion_from_euler(0, 0, theta)
    this_pose_stamped.pose.orientation = Quaternion(*quaternion)
    # 设置时间戳和坐标系
    this_pose_stamped.header.stamp = rospy.Time.now()
    this_pose_stamped.header.frame_id = "world"
    # 将当前PoseStamped添加到路径中
    path.poses.append(this_pose_stamped)
    # 不要忘记发布路径
    pub_rviz.publish(path)


if __name__ == "__main__":
    rospy.init_node("pure_pursuit")
    #时间要在初始化节点后使用
    current_time = rospy.Time.now().to_sec()
    last_time = rospy.Time.now().to_sec()
    start_time = rospy.Time.now().to_sec()
    pub_vel = rospy.Publisher("/smart/cmd_vel", Twist, queue_size=20)

    path = Path()
    path.header.frame_id = "world"
    path.header.stamp = rospy.Time.now()
    # 发布小车运动轨迹，应该是rviz会自动识别Path类型的数据！！！
    pub_rviz = rospy.Publisher("/smart/path2",Path,queue_size=100)


    rospy.Subscriber("/splinepoints", Path, pointCallback)
    rospy.Subscriber("/smart/velocity", TwistStamped, velocityCall)
    rospy.Subscriber("/smart/rear_pose", PoseStamped, poseCallback)
    current_time = rospy.get_time()  # 获取当前时间
    control_timer = rospy.Timer(rospy.Duration(0.1),pid_control_callback)  # 定时器来调度PID控制
    rospy.spin()