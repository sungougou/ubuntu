#! /usr/bin/env python
# encoding:utf-8
""" 
        说明目的：纯轨迹跟踪算法cpp的python形式；本节点的目的是通过算法发布小车的！速度！方向！
        订阅的话题：
        1、规划好的路线/splinepoints
        2、小车的位置（纯追踪法后轮中心） /smart/rear_pose
        3、小车的速度，用于计算育苗距离！/smart/velocity
        
        主函数步骤：
        1、将路径path导入，因为我们需要path的点进行运算！
        2、小车的信息肯定是下层发布的，我们需要用到小车的位置信息！
        3、小车的速度信息和育苗距离有关，即使我们发布速度命令，但不代表小车的速度就是3！！！！

        编程步骤：先把大框架写出来（如我需要接收地图信息，接收小车速度信息，接收小车位姿）；再编写回调函数
 """
import rospy
from nav_msgs.msg import Path
from geometry_msgs.msg import TwistStamped,PoseStamped,Twist
import tf_conversions
from math import pow, sqrt, atan2, sin,atan
# 1、定义全局变量等基础（我先写的是地图数据的回调函数，肯定是地图数据的变量先定义）
path_x = []#地图的横纵坐标
path_y = []
pointNum = 0#地图点的总数

PREVIEW_DIS = 3#固定扫描距离
preview_dis = 0.0
k = 0.1#速度的系数，育苗距离要用
carvel = 0.0#车速，育苗距离

Ld = 1.868#轴距，前轮到后轮的距离


#2、接收地图点的回调函数，将所有地图形式的消息数据转化为坐标形式
def pointCallback(path):
        global pointNum,path_x,path_y
        pointNum = len(path.poses)
        path_x = [pose.pose.position.x for pose in path.poses]#值得注意的是数组进行定义时必须加上方括号！
        path_y = [pose.pose.position.y for pose in path.poses]#我们对path物理意义不深，它装着路径的数据信息！！！
        rospy.loginfo("路径装填完毕")

#3、速度的回调函数，因为育苗距离是和速度紧紧挂钩的！！！只要用到动态数据的都给我搞个回调函数
def velCallback(vel):
        global preview_dis,k,carvel
        carvel = vel.twist.linear.x
        preview_dis = k *  carvel+ PREVIEW_DIS
        # rospy.loginfo("%.2f",preview_dis)

#4、核心函数，用于计算育苗点并计算小车速度和转角
def poseCallback(pose):
        global pointNum,path_x,path_y,preview_dis,k
        #  小车当前位置
        currentpositionx = pose.pose.position.x
        currentpositiony = pose.pose.position.y
        currentpositionz = 0
        #欧拉角
        oula = tf_conversions.transformations.euler_from_quaternion([pose.pose.orientation.x,
                                                                    pose.pose.orientation.y,
                                                                    pose.pose.orientation.z,
                                                                    pose.pose.orientation.w])
        #寻找育苗点：找一个最近点，并且从最近点开始向后扩张找育苗点
        bestpoints = [sqrt(pow(currentpositionx-x,2)+pow(currentpositiony-y,2)) for x,y in zip(path_x,path_y)]
        index = bestpoints.index(min(bestpoints))
        
        for i in range(index,pointNum):
                dis =  sqrt(pow(path_x[index]-path_x[i],2)+pow(path_y[index]-path_y[i],2))
                if dis >= preview_dis:
                        index = i#找到育苗点
                        break

        #核心公式，计算转动的角度,第三个才是偏航角
        alpha = atan2(path_y[index]-currentpositiony,path_x[index]-currentpositionx)-oula[2]
        goaldistance = sqrt(pow(currentpositionx-path_x[index],2)+pow(currentpositiony-path_y[index],2))
        
        #准备发布运动指令
        if goaldistance >0.2:
                twist = Twist()
                twist.linear.x = 3#定速追逐
                theta = atan(2 * Ld * sin(alpha) / goaldistance)
                twist.angular.z = theta
                pub.publish(twist)
        else:
                twist = Twist()
                twist.linear.x = 0#如果距离太近让小车停下来即可
                twist.angular.z = 0
                pub.publish(twist)
        



if __name__ == "__main__":
        # 0、初始化节点
        rospy.init_node("purepursuit")
        # 0、 创建三个订阅者，只要是接收其他数据，就必须要订阅者和回调函数！！！
        pub = rospy.Publisher("/smart/cmd_vel",Twist,queue_size=20)#我们发布者只需创建一次
        rospy.Subscriber("/splinepoints",Path,pointCallback)
        rospy.Subscriber("/smart/velocity",TwistStamped,velCallback)
        rospy.Subscriber("/smart/rear_pose",PoseStamped,poseCallback)
        rospy.spin()
