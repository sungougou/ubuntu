#! /usr/bin/env python
# encoding:utf-8
# 此版本成功运行
import rospy
from math import pow, sqrt, atan2, sin,atan
from geometry_msgs.msg import Twist, PoseStamped,TwistStamped
from nav_msgs.msg import Path
from tf.transformations import euler_from_quaternion

PREVIEW_DIS = 3  #基本预瞄距离
Ld = 1.868  #轴距，用于纯追踪法的核心公式

k = 0.1
carVelocity = 0  #初始化车速和育苗距离
preview_dis = 0

pointNum = 0  #路径点的总数，用于进行路经点索引
r_x_ = []  #数组的定义：空数组是可以的！路径的横纵坐标，我们进行任何的几何计算肯定需要点坐标！！！
r_y_ = []

def poseCallback(currentWaypoint):
    #函数中我们需要声明全局变量才有资格在函数中使用，不然默认是局部变量
    global preview_dis, pointNum, r_x_, r_y_

    currentPositionX = currentWaypoint.pose.position.x
    currentPositionY = currentWaypoint.pose.position.y
    currentPositionZ = 0.0
    
    quaternion = (
        currentWaypoint.pose.orientation.x,
        currentWaypoint.pose.orientation.y,
        currentWaypoint.pose.orientation.z,
        currentWaypoint.pose.orientation.w)
    euler = euler_from_quaternion(quaternion)
    
    # 方案二:先从当前位置附近找到一个最近点，然后从最近点往后寻找临近预眇距离的坐标点
    bestPoints_ = [sqrt(pow(x - currentPositionX, 2) + pow(y - currentPositionY, 2)) for x, y in zip(r_x_, r_y_)]
    index = bestPoints_.index(min(bestPoints_))

    for i in range(index, pointNum):
        dis = sqrt(pow(r_y_[index] - r_y_[i], 2) + pow(r_x_[index] - r_x_[i], 2));
        # 目标点：选取离最近点育苗距离的点作为育苗点！
        if dis >= preview_dis:
            index = i
            break

    alpha = atan2(r_y_[index] - currentPositionY, r_x_[index] - currentPositionX) - euler[2]

    # 如果育苗点距离太近，停止运动
    dl = sqrt(pow(r_y_[index] - currentPositionY, 2) + pow(r_x_[index] - currentPositionX, 2))
    if dl > 0.2:
        vel_msg = Twist()
        vel_msg.linear.x = 3
        theta = atan(2 * Ld * sin(alpha) / dl)
        vel_msg.angular.z = theta
        pub_vel.publish(vel_msg)
    else:
        vel_msg = Twist()
        vel_msg.linear.x = 0
        vel_msg.angular.z = 0
        pub_vel.publish(vel_msg)

def velocityCall(carWaypoint):
    global carVelocity, preview_dis
    carVelocity = carWaypoint.twist.linear.x
    preview_dis = k * carVelocity + PREVIEW_DIS

def pointCallback(msg):
    global pointNum, r_x_, r_y_
    pointNum = len(msg.poses)
    r_x_ = [pose.pose.position.x for pose in msg.poses]
    r_y_ = [pose.pose.position.y for pose in msg.poses]

if __name__ == "__main__":
    rospy.init_node("pure_pursuit")
    pub_vel = rospy.Publisher("/smart/cmd_vel", Twist, queue_size=20)

    path = Path()
    path.header.frame_id = "world"
    path.header.stamp = rospy.Time.now()

    rospy.Subscriber("/splinepoints", Path, pointCallback)
    rospy.Subscriber("/smart/velocity", TwistStamped, velocityCall)
    rospy.Subscriber("/smart/rear_pose", PoseStamped, poseCallback)

    rospy.spin()