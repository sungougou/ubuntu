#!/usr/bin/env python
# encoding:utf-8
# 这个当作轨迹跟踪的模板！！！
import rospy
from geometry_msgs.msg import Twist, PoseStamped,TwistStamped
from tf.transformations import euler_from_quaternion
from nav_msgs.msg import Path
from math import pow, sqrt, atan2, sin,atan

PREVIEW_DIS = 3 
Ld = 1.868  
k = 0.1

carVelocity = 0  
preview_dis = 0
pointNum = 0 

r_x_ = []  
r_y_ = []


def poseCallback(currentWaypoint):
    global preview_dis, pointNum, r_x_, r_y_

    currentPositionX = currentWaypoint.pose.position.x
    currentPositionY = currentWaypoint.pose.position.y
    currentPositionZ = 0.0

    quaternion = (
        currentWaypoint.pose.orientation.x,
        currentWaypoint.pose.orientation.y,
        currentWaypoint.pose.orientation.z,
        currentWaypoint.pose.orientation.w)
    euler = euler_from_quaternion(quaternion)

    bestPoints_ = [sqrt(pow(x - currentPositionX, 2) + pow(y - currentPositionY, 2)) for x, y in zip(r_x_, r_y_)]
    index = bestPoints_.index(min(bestPoints_))

    for i in range(index, pointNum):
        dis = sqrt(pow(r_y_[index] - r_y_[i], 2) + pow(r_x_[index] - r_x_[i], 2))
        if dis >= preview_dis:
            index = i
            break

    alpha = atan2(r_y_[index] - currentPositionY, r_x_[index] - currentPositionX) - euler[2]
    
    dl = sqrt(pow(r_y_[index] - currentPositionY, 2) + pow(r_x_[index] - currentPositionX, 2))
    if dl > 0.2:
        theta = atan(2 * Ld * sin(alpha) / dl)
        vel_msg = Twist()
        vel_msg.linear.x = 3
        vel_msg.angular.z = theta
        pub_vel.publish(vel_msg)
    else:
        vel_msg = Twist()
        vel_msg.linear.x = 0
        vel_msg.angular.z = 0
        pub_vel.publish(vel_msg)


def velocityCall(carWaypoint):
    global carVelocity, preview_dis
    carVelocity = carWaypoint.twist.linear.x
    preview_dis = k * carVelocity + PREVIEW_DIS

def pointCallback(msg):
    global pointNum, r_x_, r_y_
    pointNum = len(msg.poses)
    r_x_ = [pose.pose.position.x for pose in msg.poses]
    r_y_ = [pose.pose.position.y for pose in msg.poses]

if __name__ == "__main__":
    rospy.init_node("pure_pursuit")

    pub_vel = rospy.Publisher("/smart/cmd_vel", Twist, queue_size=20)
    rospy.Subscriber("/splinepoints", Path, pointCallback)
    rospy.Subscriber("/smart/velocity", TwistStamped, velocityCall)
    rospy.Subscriber("/smart/rear_pose", PoseStamped, poseCallback)

    rospy.spin()