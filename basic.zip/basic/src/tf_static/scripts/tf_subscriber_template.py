#! /usr/bin/env python
# encoding:utf-8
""" 
        tf静态坐标订阅：导包、创建节点、创建订阅者、创建laser坐标系中的点，并且进行坐标变换
        1、导包，静态坐标订阅需要tf2_ros、msgs、tf等功能包
        2、创建节点
        3、创建tf坐标监听者，并且监听消息存储在buffer中
        4、循环发布rate
        
 """
import rospy
import tf2_ros
# tmd要用tf2封装好的msg，而不是传统的msg包！！！
from tf2_geometry_msgs import PointStamped

if __name__ == "__main__":
        # 2、创建节点
        rospy.init_node("tf_subscriber_template")
        # 3、创建tf坐标专门订阅者
        buffer = tf2_ros.Buffer()
        listener = tf2_ros.TransformListener(buffer)
        # 每一秒发布一次点的相对坐标
        rate = rospy.Rate(1)

        while not rospy.is_shutdown():
                try:
                        point_source = PointStamped()
                        # 在点坐标中指明了所属坐标系
                        point_source.header.frame_id = "laser"
                        point_source.header.stamp = rospy.Time.now()

                        point_source.point.x = 1.0
                        point_source.point.y = 2.0
                        point_source.point.z = 3.0
                        point_target = buffer.transform(point_source,"base_link")
                        rospy.loginfo("在主坐标系下的点坐标为：%.2f,%.2f,%.2f",
                                      point_target.point.x,
                                      point_target.point.y,
                                      point_target.point.z)
                except Exception as e:
                        rospy.loginfo("异常：%s",e)
        # 4、循环发布
                rate.sleep()