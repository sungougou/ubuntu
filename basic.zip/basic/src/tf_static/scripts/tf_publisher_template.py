#! /usr/bin/env python
# encoding:utf-8
""" 
        tf静态坐标发布：导包、创建节点、创建发布者、创建发布消息、发布、spin
        1、导包，静态坐标发布需要tf2_ros、geometry_msgs、tf等功能包
        2、创建节点
        3、创建tf坐标专门发布者
        4、创建tf消息并且发布
        5、spin
 """
import rospy
import tf2_ros
from geometry_msgs.msg import TransformStamped
import tf_conversions

if __name__ == "__main__":
        # 2、创建节点
        rospy.init_node("tf_publisher")
        # 3、创建tf坐标专门发布者
        broadcaster = tf2_ros.StaticTransformBroadcaster()
        # 4、创建tf消息并且发布
        tfmsg = TransformStamped()
        tfmsg.header.frame_id = "base_link"
        tfmsg.header.stamp = rospy.Time.now()
        tfmsg .child_frame_id = "laser"
        # 物理意义就是坐标系相对关系
        tfmsg.transform.translation.x = 2.0
        tfmsg.transform.translation.y = 0.0
        tfmsg.transform.translation.z = 0.0

        qtn = tf_conversions.transformations.quaternion_from_euler(0,0,0)
        tfmsg.transform.rotation.x = qtn[0]
        tfmsg.transform.rotation.y = qtn[1]
        tfmsg.transform.rotation.z = qtn[2]
        tfmsg.transform.rotation.w = qtn[3]

        broadcaster.sendTransform(tfmsg)
        rospy.loginfo("消息数据成功发送！")
        # 5、spin
        rospy.spin()