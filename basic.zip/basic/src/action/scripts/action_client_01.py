#! /usr/bin/env python
# encoding:utf-8
""" 
        说明：客户端实现
        1、创建客户端并启动客户端
        2、创建发布消息
        3、发布消息并编写三个回调函数
        4、spin()
 """
import rospy
import actionlib
from action.msg import *

class myclient():
        def __init__(self):
        # 1、创建客户端并启动客户端
                self.client = actionlib.SimpleActionClient("test_01",suckAction)
                self.client.wait_for_server()
                rospy.loginfo("客户端启动")
        # 2、创建发布消息
                suck = suckActionGoal()
                suck.goal = "sunkexuan"
        # 3、发布消息并编写三个回调函数
                self.client.send_goal(suck,self.done_cb,self.active_cb,self.feedback_cb)
        # 4、spin()
                rospy.spin()
# done_cb;active_cb;feedback_cb
        def active_cb(self):
                rospy.loginfo("成功建立起连接！")
        
        def feedback_cb(self,feedback):
                rospy.loginfo(feedback)

        def done_cb(self,state,result):
                rospy.loginfo(result)




if __name__ == "__main__":
        rospy.init_node("action_client_01")
        client = myclient()
