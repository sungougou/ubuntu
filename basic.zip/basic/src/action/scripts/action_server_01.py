#! /usr/bin/env python
# encoding:utf-8
""" 
        说明：action的服务端（模板）
        需求：创建两个节点，服务端和客户端，做一些有趣的事情，每0.1秒服务端会给一个反馈
        1、编写回调函数
        2、初始化节点
        3、封装一个类
        4、创建服务端对象
        5、回调函数处理请求
        6、spin()
 """
import rospy
# 这个库用来创建服务端
import actionlib
from action.msg import *

#  创建一个类，直接满足服务器所有函数！
class myserver():
        def __init__(self):
                # 创建服务端
                self.server = actionlib.SimpleActionServer("test_01",suckAction,self.callback,False)
                self.server.start()
                rospy.loginfo("服务端启动！")

        def callback(self,goal):
                # 1、接收goal的消息
                dicker = goal.goal
                rospy.loginfo("YY suck "+ dicker + " 's dick")
                rate = rospy.Rate(1)
                # 2、实时进行反馈
                for i in range(1,10):
                        feedback = suckFeedback()
                        feedback.feedback = "I am coming out!!!"
                        self.server.publish_feedback(feedback)
                        rospy.loginfo(feedback.feedback)
                        rate.sleep()
                # 3、程序结束运行
                rospy.loginfo("程序运行结束！")
                result = suckResult()
                result.result = "A!!!wonderful!!!"
                self.server.set_succeeded(result)



        
if __name__ == "__main__":
        rospy.init_node("action_server_01")
        server = myserver()
        # 因为我要等待客户端！！！肯定要spin()
        rospy.spin()