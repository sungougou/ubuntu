#! /usr/bin/env python
# encoding:utf-8
""" 
        说明：复习服务通信客户端发送请求
        1、初始化节点
        2、创建客户端对象
        3、创建发送数据dick
        4、发送并且等待
 """
import rospy
from client_server.srv import *
if __name__ == "__main__":
        # 1、初始化节点
        rospy.init_node("recover_client")
        # 2、创建客户端对象
        client = rospy.ServiceProxy("taste",dick)
        # 3、创建发送数据dick
        request = dick()
        request.sucker = "yuyue"
        request.dicker = "sunkexuan"
        # 4、发送并且等待
        client.wait_for_service()
        response = client.call(request.sucker,request.dicker)
        rospy.loginfo("%s",response.taste)
        rospy.spin()