#! /usr/bin/env python
# encoding: utf-8
import rospy #导包
from client_server.srv import *

import sys
""" 
1、初始化节点
2、创建服务端对象
3、发送数据
4、处理响应
5、优化启动客户端时同时输入参数
 """
if __name__ == "__main__":
    #1、启动节点
    rospy.init_node("test_client_01")
    
    #不需要任何代码参数已经在里面
    if len(sys.argv) != 3:
        sys.exit(1)

    #2、创建服务端
    client = rospy.ServiceProxy("server_topic_01",addints)

    #3、发送数据
    num1 = int(sys.argv[1])
    num2 = int(sys.argv[2])

    #判断服务器状态
    client.wait_for_service()
    
    response = client.call(num1,num2)

    #4、处理响应
    rospy.loginfo("响应数据：%d",response.sum)
  
