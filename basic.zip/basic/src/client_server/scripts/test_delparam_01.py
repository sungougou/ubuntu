#! /usr/bin/env python
# encoding: utf-8
import rospy #导包

if __name__ == "__main__":
    rospy.init_node("test_delparam_01")
    try:
        rospy.delete_param("height")
    except Exception as e:
        rospy.loginfo("没有要删除的键")
  

