#! /usr/bin/env python
# encoding: utf-8
import rospy #导包
from std_msgs.msg import String 

if __name__ == "__main__":
    rospy.init_node("test_setparam_01")
    rospy.set_param("name","孙克璇")
    rospy.set_param("age",23)
    
