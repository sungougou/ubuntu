#! /usr/bin/env python
# encoding:utf-8
""" 
        说明：复习服务通信服务端
        1、创建回调函数
        2、创建服务端
        3、等待客户端spin()
 """
import rospy
from client_server.srv import *

def domsg(request):
        response = dickResponse()
        response.taste = request.sucker + " loves " + request.dicker + " 's dick"
        return response
        

if __name__ == "__main__":
        rospy.init_node("recover_server")
        # 2、创建服务端
        server = rospy.Service("taste",dick,domsg)
        rospy.loginfo("服务端成功启动！")
        # 3、等待客户端spin()
        rospy.spin()