#! /usr/bin/env python
# encoding: utf-8
import rospy #导包

from client_server.srv import *

def doints(request):
    #切记服务器返回的结果要封装！！！自己创建addints的类时，addintsRequest和addintsResponse自动生成
    response = addintsResponse();
    response.sum = request.num1+request.num2;
    #确认服务器启动
    rospy.loginfo("服务器返回参数：%d",response.sum);
    return response

if __name__ == "__main__":
    rospy.init_node("test_server_01");
    #创建服务端
    serve = rospy.Service("server_topic_01",addints,doints);
    #确认服务器启动
    rospy.loginfo("服务器已经启动了！");
    #回调函数等待
    rospy.spin();
  
