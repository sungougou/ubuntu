#! /usr/bin/env python
# encoding:utf-8
""" 
服务话题（服务话题也是话题！！！）：/spawn
数据类型：turtlesim/Spawn
参数：x y theta name
        调用服务端，其实和收发话题消息一样简单，看作通信即可
        1、导包，正常的turtlesim包即可
        2、创建节点
        3、创建服务端对象
        4、对服务端对象启用rosservice call一样功能的命令
        由于不用处理新消息，调用服务完成即可结束
 """
import rospy
# 服务通信的数据类型是srv！！！
from turtlesim.srv import *

if __name__ == "__main__":
        # 2、创建节点
        rospy.init_node("turtle_spawn")
        # 3、创建客户端对象(话题，数据)
        client = rospy.ServiceProxy("/spawn",Spawn)
        # 等待服务端启动！
        client.wait_for_service()
        # 4、对服务端对象启用rosservice call一样功能的命令——client.call()
        req = SpawnRequest()
        req.x = 10
        req.y = 10
        req.theta = 0
        req.name = "turtle2"
        try:
                client.call(req)
        except Exception as e:
                rospy.loginfo("异常：%s",e)