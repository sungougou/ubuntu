#! /usr/bin/env python
# encoding:utf-8
"""
        值得注意：乌龟坐标系就是乌龟的位置！！！坐标系都是自己定的
        话题：/turtle1/pose
        tf动态坐标订阅：动态坐标、静态坐标订阅逻辑一样，只是循环处理速度快一些就行
        1、导包，静态坐标订阅需要tf2_ros、msgs、tf等功能包
        2、创建节点
        3、创建tf坐标监听者，并且监听消息存储在buffer中
        4、循环处理数据rate
        
 """
import rospy
import tf2_ros
# tmd要用tf2封装好的msg，而不是传统的msg包！！！
from tf2_geometry_msgs import PointStamped
from geometry_msgs.msg import TransformStamped
# 乌龟速度信息
from geometry_msgs.msg import Twist
# 数学库
import math



if __name__ == "__main__":
        # 2、创建节点
        rospy.init_node("subscriber_template")
        # 3、创建tf坐标专门订阅者，但是这个listener没有指定听哪个tf坐标！！！
        buffer = tf2_ros.Buffer()
        listener = tf2_ros.TransformListener(buffer)
        # 每一秒发布一次点的相对坐标
        rate = rospy.Rate(10)
        # 4、给2乌龟发送速度指令
        pub = rospy.Publisher("/turtle2/cmd_vel",Twist,queue_size=1000)


        while not rospy.is_shutdown():
                try:
                        tfs = buffer.lookup_transform("turtle2","turtle1",rospy.Time(0))
                        # 乌龟速度话题/turtle2/cmd_vel
                        # 乌龟速度数据类型Twist
                        twist = Twist()
                        twist.linear.x = 0.5 * math.sqrt(math.pow(tfs.transform.translation.x,2) + math.pow(tfs.transform.translation.y,2))
                        twist.angular.z = 4 * math.atan2(tfs.transform.translation.y, tfs.transform.translation.x)
                        pub.publish(twist)
                        rospy.loginfo("相对坐标：%f,%f",tfs.transform.translation.x,tfs.transform.translation.y)
                except Exception as e:
                        rospy.loginfo("异常：%s",e)
        # 4、循环发布
                rate.sleep()