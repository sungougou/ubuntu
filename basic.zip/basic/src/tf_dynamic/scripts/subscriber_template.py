#! /usr/bin/env python
# encoding:utf-8
"""
        值得注意：乌龟坐标系就是乌龟的位置！！！坐标系都是自己定的
        话题：/turtle1/pose
        tf动态坐标订阅：动态坐标、静态坐标订阅逻辑一样，只是循环处理速度快一些就行
        1、导包，静态坐标订阅需要tf2_ros、msgs、tf等功能包
        2、创建节点
        3、创建tf坐标监听者，并且监听消息存储在buffer中
        4、循环处理数据rate
        
 """
import rospy
import tf2_ros
# tmd要用tf2封装好的msg，而不是传统的msg包！！！
from tf2_geometry_msgs import PointStamped

if __name__ == "__main__":
        # 2、创建节点
        rospy.init_node("subscriber_template")
        # 3、创建tf坐标专门订阅者
        buffer = tf2_ros.Buffer()
        listener = tf2_ros.TransformListener(buffer)
        # 每一秒发布一次点的相对坐标
        rate = rospy.Rate(10)

        while not rospy.is_shutdown():
                try:
                        point_source = PointStamped()
                        # 在点坐标中指明了所属坐标系
                        point_source.header.frame_id = "tuetle1"
                        point_source.header.stamp = rospy.Time.now()

                        point_source.point.x = 3.0
                        point_source.point.y = 0.0
                        point_source.point.z = 0.0
                        point_target = buffer.transform(point_source,"worlds")
                        rospy.loginfo("在主坐标系下的点坐标为：%.2f,%.2f,%.2f",
                                      point_target.point.x,
                                      point_target.point.y,
                                      point_target.point.z)
                except Exception as e:
                        rospy.loginfo("异常：%s",e)
        # 4、循环发布
                rate.sleep()