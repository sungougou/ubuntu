#! /usr/bin/env python
# encoding:utf-8
""" 
        动态坐标发布：发布两只乌龟相对的坐标
        话题：/turtle1/pose
        数据类型：Type: turtlesim/Pose
        1、导包，静态坐标发布需要tf2_ros、geometry_msgs、tf等功能包
        2、创建回调函数订阅乌龟位姿，订阅位姿就可以创建坐标系！！！顺便再发布tf动态坐标
        3、在主函数中spin等待即可！
 """
import rospy
from turtlesim.msg import Pose
import tf2_ros
from geometry_msgs.msg import TransformStamped
import tf_conversions

def domsg1(msg):
        tfmsg = TransformStamped()
        tfmsg.header.frame_id = "worlds"
        tfmsg.header.stamp = rospy.Time.now()
        tfmsg .child_frame_id = "turtle1"
        
        # 物理意义就是坐标系相对关系
        tfmsg.transform.translation.x = msg.x
        tfmsg.transform.translation.y = msg.y
        tfmsg.transform.translation.z = 0

        qtn = tf_conversions.transformations.quaternion_from_euler(0,0,msg.theta)
        tfmsg.transform.rotation.x = qtn[0]
        tfmsg.transform.rotation.y = qtn[1]
        tfmsg.transform.rotation.z = qtn[2]
        tfmsg.transform.rotation.w = qtn[3]
        # 创建广播发布者
        broadcaster = tf2_ros.StaticTransformBroadcaster()
        # 发布消息
        broadcaster.sendTransform(tfmsg)
def domsg2(msg):
        tfmsg = TransformStamped()
        tfmsg.header.frame_id = "worlds"
        tfmsg.header.stamp = rospy.Time.now()
        tfmsg .child_frame_id = "turtle2"
        
        # 物理意义就是坐标系相对关系
        tfmsg.transform.translation.x = msg.x
        tfmsg.transform.translation.y = msg.y
        tfmsg.transform.translation.z = 0

        qtn = tf_conversions.transformations.quaternion_from_euler(0,0,msg.theta)
        tfmsg.transform.rotation.x = qtn[0]
        tfmsg.transform.rotation.y = qtn[1]
        tfmsg.transform.rotation.z = qtn[2]
        tfmsg.transform.rotation.w = qtn[3]
        # 创建广播发布者
        broadcaster = tf2_ros.TransformBroadcaster()
        # 发布消息
        broadcaster.sendTransform(tfmsg)

if __name__ == "__main__":
        rospy.init_node("publisher_template")
        sub1 = rospy.Subscriber("/turtle1/pose",Pose,domsg1,queue_size=100)
        sub2 = rospy.Subscriber("/turtle2/pose",Pose,domsg2,queue_size=100)
        # 这个函数就是死循环，直到有新消息，并且只执行新消息！！！
        rospy.spin()

 