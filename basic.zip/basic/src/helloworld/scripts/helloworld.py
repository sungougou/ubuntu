#! /usr/bin/env python


import rospy

if __name__ == "__main__":
    rospy.init_node("helloworld")
    rospy.loginfo("Hello World!!!!")