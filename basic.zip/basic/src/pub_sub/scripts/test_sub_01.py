#! /usr/bin/env python
# encoding: utf-8
import rospy #导包
from std_msgs.msg import String #消息数据类型包
""" 
        说明：正常订阅方
 """
#回调函数
def domsg(msg):#将数据放入msg变量中
    rospy.loginfo("受到的数据是：%s",msg.data);

if __name__ == "__main__":
    rospy.init_node("test_sub_01");
    #创建话题订阅者
    sub = rospy.Subscriber("test_topic_01", String, domsg,queue_size=10);
    #执行回调函数，不需要声明
    #等待回调函数
    rospy.spin();

