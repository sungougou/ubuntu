#! /usr/bin/env python
# encoding: utf-8
import rospy #导包
from std_msgs.msg import String #消息数据类型包
""" 
        说明：正常发布方
 """
if __name__ == "__main__":
    rospy.init_node("test_pub_01");
    #创建话题发布者
    pub = rospy.Publisher("test_topic_01",String,queue_size=10);
    #创建发布消息
    msg = String();
    #规定频率
    rate = rospy.Rate(1);
    count = 0;
    #先休眠三秒钟等待订阅方
    rospy.sleep(3);
    #循环发布消息
    while not rospy.is_shutdown():
        count  += 1;
        msg.data = "skx handsome" + str(count);
        pub.publish(msg);
        rospy.loginfo("孙克璇真帅！%s，%s",msg.data);
        rate.sleep();
