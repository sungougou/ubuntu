#! /usr/bin/env python
# encoding: utf-8
import rospy
from pub_sub.msg import people

if __name__ == "__main__":
    # 1、初始化ros节点
    rospy.init_node("test_pub_02");
    # 2、创建发布者
    pub = rospy.Publisher("test_topic_02",people,queue_size=10);
    # 3、创建数据类型（类似结构体）
    p = people();
    p.name = "skx";
    p.age = 23;
    p.height = 170;
    # 间隔一秒发出数据
    rate = rospy.Rate(1);
    # 4、循环发布数据
    while not rospy.is_shutdown():
        pub.publish(p);
        rospy.loginfo("发布的话题数据是：%s,%d,%f",p.name,p.age,p.height);
        rate.sleep();

    