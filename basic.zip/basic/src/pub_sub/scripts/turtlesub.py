#! /usr/bin/env python
# encoding: utf-8
import rospy #导包
from pub_sub.msg import turtlepose
from turtlesim.msg import Pose
""" 
    订阅乌龟位姿话题、发布自定义话题
 """

def dopose(pose):
    #回调函数在接受话题信息时只执行一次
    temp.x = pose.x
    temp.y = pose.y
    temp.theta = pose.theta

# def domsg(msg):#将数据放入msg变量中
#     rospy.loginfo("受到的数据是：%s,%d,%f",msg.name,msg.age,msg.height);


if __name__ == "__main__":
    rospy.init_node("turtlesub")
    #订阅步骤：订阅对象、回调函数、切记要发送的消息类型可以定义在主函数中！
    sub = rospy.Subscriber("/turtle1/pose",Pose,dopose,queue_size=10)
    #创建乌龟位姿数据类型，等待回调函数执行
    temp = turtlepose()
    rospy.spin()
    #发布步骤：发布对象、创建发布数据、发布
    pub = rospy.Publisher("turtlepose",turtlepose,queue_size=10)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        pub.publish(temp)
        rate.sleep()