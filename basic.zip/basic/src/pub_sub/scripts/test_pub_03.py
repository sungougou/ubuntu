#! /usr/bin/env python
# encoding:utf-8
""" 
        说明：复习使用自定义消息数据、发布话题
 """
import rospy
from pub_sub.msg import test

if __name__ == "__main__":
    rospy.init_node("test_pub_03");
    #创建话题发布者
    pub = rospy.Publisher("test_topic_03",test,queue_size=10);
    #创建发布消息
    msg = test();
    #规定频率
    rate = rospy.Rate(1);
    count = 0;
    #先休眠三秒钟等待订阅方
    rospy.sleep(3);
    #循环发布消息
    while not rospy.is_shutdown():
        count  += 1;
        msg.dick = "skx"
        msg.taste = "yy"
        pub.publish(msg);
        rospy.loginfo("发布成功！%s,%s",msg.dick,msg.taste);
        rate.sleep();
