#! /usr/bin/env python
# encoding: utf-8
import rospy #导包
from pub_sub.msg import people #消息数据类型包

#回调函数
def domsg(msg):#将数据放入msg变量中
    rospy.loginfo("受到的数据是：%s,%d,%f",msg.name,msg.age,msg.height);

if __name__ == "__main__":
    rospy.init_node("test_sub_02");
    #创建话题订阅者
    sub = rospy.Subscriber("test_topic_02", people, domsg,queue_size=10);
    #执行回调函数，不需要声明
    #等待回调函数
    rospy.spin();
