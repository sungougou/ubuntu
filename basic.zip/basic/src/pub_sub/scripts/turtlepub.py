#! /usr/bin/env python
# encoding: utf-8

import rospy
from geometry_msgs.msg import Twist
""" 
        创建乌龟发布话题、使用已有消息不需要导包、控制小乌龟运动
 """

if __name__ == "__main__":
    # 初始化节点
    rospy.init_node("turtlepub")
    #创建发布者
    pub = rospy.Publisher("/turtle1/cmd_vel",Twist,queue_size=10)
    #创建发布数据
    twist = Twist()
    #处理数据信息，rate，twist都是实例对象
    rate = rospy.Rate(10)
    twist.linear.x = 1.0
    twist.linear.y = 0.0
    twist.linear.z = 0.0
    twist.angular.x = 0.0
    twist.angular.y = 0.0
    twist.angular.z = 1.0


    while not rospy.is_shutdown():
        pub.publish(twist)
        rate.sleep()#可以把它当作结尾