// Auto-generated. Do not edit!

// (in-package pub_sub.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class test {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.dick = null;
      this.taste = null;
    }
    else {
      if (initObj.hasOwnProperty('dick')) {
        this.dick = initObj.dick
      }
      else {
        this.dick = '';
      }
      if (initObj.hasOwnProperty('taste')) {
        this.taste = initObj.taste
      }
      else {
        this.taste = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type test
    // Serialize message field [dick]
    bufferOffset = _serializer.string(obj.dick, buffer, bufferOffset);
    // Serialize message field [taste]
    bufferOffset = _serializer.string(obj.taste, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type test
    let len;
    let data = new test(null);
    // Deserialize message field [dick]
    data.dick = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [taste]
    data.taste = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.dick.length;
    length += object.taste.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pub_sub/test';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '80056762e4ccd3bd15d8448de4daa283';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string dick
    string taste
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new test(null);
    if (msg.dick !== undefined) {
      resolved.dick = msg.dick;
    }
    else {
      resolved.dick = ''
    }

    if (msg.taste !== undefined) {
      resolved.taste = msg.taste;
    }
    else {
      resolved.taste = ''
    }

    return resolved;
    }
};

module.exports = test;
