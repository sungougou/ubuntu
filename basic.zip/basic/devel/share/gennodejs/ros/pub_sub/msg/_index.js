
"use strict";

let people = require('./people.js');
let test = require('./test.js');
let turtlepose = require('./turtlepose.js');

module.exports = {
  people: people,
  test: test,
  turtlepose: turtlepose,
};
