// Auto-generated. Do not edit!

// (in-package client_server.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class dickRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sucker = null;
      this.dicker = null;
    }
    else {
      if (initObj.hasOwnProperty('sucker')) {
        this.sucker = initObj.sucker
      }
      else {
        this.sucker = '';
      }
      if (initObj.hasOwnProperty('dicker')) {
        this.dicker = initObj.dicker
      }
      else {
        this.dicker = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type dickRequest
    // Serialize message field [sucker]
    bufferOffset = _serializer.string(obj.sucker, buffer, bufferOffset);
    // Serialize message field [dicker]
    bufferOffset = _serializer.string(obj.dicker, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type dickRequest
    let len;
    let data = new dickRequest(null);
    // Deserialize message field [sucker]
    data.sucker = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [dicker]
    data.dicker = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.sucker.length;
    length += object.dicker.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'client_server/dickRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2c82d49f85ed533d2bf0410781c54f90';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string sucker
    string dicker
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new dickRequest(null);
    if (msg.sucker !== undefined) {
      resolved.sucker = msg.sucker;
    }
    else {
      resolved.sucker = ''
    }

    if (msg.dicker !== undefined) {
      resolved.dicker = msg.dicker;
    }
    else {
      resolved.dicker = ''
    }

    return resolved;
    }
};

class dickResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.taste = null;
    }
    else {
      if (initObj.hasOwnProperty('taste')) {
        this.taste = initObj.taste
      }
      else {
        this.taste = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type dickResponse
    // Serialize message field [taste]
    bufferOffset = _serializer.string(obj.taste, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type dickResponse
    let len;
    let data = new dickResponse(null);
    // Deserialize message field [taste]
    data.taste = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.taste.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'client_server/dickResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a1100ea11eec3032a1eb95e7e24d3d8c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string taste
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new dickResponse(null);
    if (msg.taste !== undefined) {
      resolved.taste = msg.taste;
    }
    else {
      resolved.taste = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: dickRequest,
  Response: dickResponse,
  md5sum() { return 'bc5fc97a88a989ee89eea21d2bba9cce'; },
  datatype() { return 'client_server/dick'; }
};
