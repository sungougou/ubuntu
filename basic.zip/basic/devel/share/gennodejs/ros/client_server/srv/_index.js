
"use strict";

let addints = require('./addints.js')

module.exports = {
  addints: addints,
};
