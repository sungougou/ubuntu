
"use strict";

let dick = require('./dick.js')
let addints = require('./addints.js')

module.exports = {
  dick: dick,
  addints: addints,
};
