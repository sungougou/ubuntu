
"use strict";

let suckActionGoal = require('./suckActionGoal.js');
let suckFeedback = require('./suckFeedback.js');
let suckGoal = require('./suckGoal.js');
let suckActionResult = require('./suckActionResult.js');
let suckActionFeedback = require('./suckActionFeedback.js');
let suckAction = require('./suckAction.js');
let suckResult = require('./suckResult.js');

module.exports = {
  suckActionGoal: suckActionGoal,
  suckFeedback: suckFeedback,
  suckGoal: suckGoal,
  suckActionResult: suckActionResult,
  suckActionFeedback: suckActionFeedback,
  suckAction: suckAction,
  suckResult: suckResult,
};
